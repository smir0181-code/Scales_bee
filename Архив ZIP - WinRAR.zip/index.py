from app import app as flask_app

def handler(event, context):
    """
    WSGI-адаптер для запуска Flask-приложения в Yandex Cloud Functions.
    """
    # Определяем схему (http или https) из заголовков
    headers = event.get('headers', {})
    proto = headers.get('X-Forwarded-Protocol', headers.get('X-Forwarded-Proto', 'https'))
    
    # Создаем WSGI-среду (environ) из словаря 'event'
    environ = {
        'REQUEST_METHOD': event.get('httpMethod', 'GET'),
        'SCRIPT_NAME': '',
        'PATH_INFO': event.get('path', '/'),
        'QUERY_STRING': event.get('queryStringParameters', '') or '',
        'CONTENT_TYPE': headers.get('Content-Type', ''),
        'CONTENT_LENGTH': headers.get('Content-Length', ''),
        'SERVER_NAME': 'localhost',
        'SERVER_PORT': '80',
        'SERVER_PROTOCOL': 'HTTP/1.1',
        'wsgi.version': (1, 0),
        'wsgi.url_scheme': proto,
        'wsgi.input': event.get('body', ''),
        'wsgi.errors': None,
        'wsgi.multithread': False,
        'wsgi.multiprocess': True,
        'wsgi.run_once': True,
        # Дополнительные полезные ключи
        'REMOTE_ADDR': headers.get('X-Real-IP', ''),
        'HTTP_HOST': headers.get('Host', ''),
    }
    
    # Копируем все заголовки из запроса в переменные HTTP_
    for key, value in headers.items():
        environ['HTTP_' + key.upper().replace('-', '_')] = value

    response_status = None
    response_headers = []

    def start_response(status, headers, exc_info=None):
        nonlocal response_status, response_headers
        response_status = status
        response_headers = headers
        return None

    response_body = flask_app(environ, start_response)
    body = ''.join([chunk.decode('utf-8') for chunk in response_body])
    status_code = int(response_status.split()[0])

    return {
        'statusCode': status_code,
        'headers': dict(response_headers),
        'body': body
    }